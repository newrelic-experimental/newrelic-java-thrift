package com.nr.instrumentation.thrift;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import org.apache.thrift.TException;
import org.apache.thrift.protocol.TProtocol;


public class HeaderHandler implements NewRelic.Iface {
	
	private static HashMap<TProtocol, HeaderHandler> handlers = new HashMap<>();

	
	public HeaderHandler() {
	}

	@Override
	public void send(Map<String, String> headers) throws TException {
		System.out.println("Received headers:");
		Set<String> keys = headers.keySet();
		for(String key : keys) {
			System.out.println("\t"+key+": "+headers.get(key));
		}
		
	}

	@Override
	public boolean ping() throws TException {
		System.out.println("Call to ping");
		return true;
	}

}
