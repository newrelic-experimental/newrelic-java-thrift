package com.nr.instrumentation.thrift;

import java.util.HashMap;
import java.util.logging.Level;

import org.apache.thrift.TException;
import org.apache.thrift.protocol.TProtocol;

import com.newrelic.api.agent.NewRelic;
import com.nr.instrumentation.thrift.NewRelic.Client;

public class HeaderSender {
	
	public static HashMap<TProtocol, Boolean> NREnabledConnections = new HashMap<>();
	
	public static boolean checkIfNewRelicPresent(TProtocol protocol) {
		if(NREnabledConnections.containsKey(protocol)) {
			return NREnabledConnections.get(protocol);
		}
		
		Client client = new Client(protocol);
		try {
			boolean b = client.ping();
			NREnabledConnections.put(protocol, b);
			return b;
		} catch (TException e) {
			NewRelic.getAgent().getLogger().log(Level.FINE, e, "Error finding NewRelic on protocol: ",protocol);
			NREnabledConnections.put(protocol, false);
			return false;
		}
	}

	public static void attemptToSendHeaders(TProtocol protocol, NRThriftHeaders headers) {
		if (NREnabledConnections.containsKey(protocol)) {
			if (headers != null && !headers.isEmpty()) {
				Client client = new Client(protocol);
				try {
					client.send(headers);
				} catch (TException e) {
					NewRelic.getAgent().getLogger().log(Level.FINE, e, "Error sending headers on protocol: ",protocol);
				}
			} 
		}
	}
}
