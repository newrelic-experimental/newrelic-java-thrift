package org.apache.thrift;

import com.newrelic.api.agent.NewRelic;
import com.newrelic.api.agent.Trace;
import com.newrelic.api.agent.weaver.MatchType;
import com.newrelic.api.agent.weaver.Weave;
import com.newrelic.api.agent.weaver.Weaver;

@SuppressWarnings("rawtypes")
@Weave(type=MatchType.BaseClass, originalName = "org.apache.thrift.TServiceClient")
public abstract class TServiceClient_instrumentation {

	@Trace
	protected void sendBase(String methodName, TBase args)  {
		NewRelic.getAgent().getTracedMethod().setMetricName("Custom","TServiceClient",getClass().getSimpleName(),"sendBase",methodName);
		Weaver.callOriginal();
	}
	
	@Trace
	protected void receiveBase(TBase result, String methodName) {
		NewRelic.getAgent().getTracedMethod().setMetricName("Custom","TServiceClient",getClass().getSimpleName(),"receiveBase",methodName);
		Weaver.callOriginal();
	}
}
