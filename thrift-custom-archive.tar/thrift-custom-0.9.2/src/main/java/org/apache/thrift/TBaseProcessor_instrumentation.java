package org.apache.thrift;

import org.apache.thrift.protocol.TProtocol;

import com.newrelic.api.agent.Trace;
import com.newrelic.api.agent.weaver.MatchType;
import com.newrelic.api.agent.weaver.Weave;
import com.newrelic.api.agent.weaver.Weaver;

@Weave(type = MatchType.BaseClass, originalName = "org.apache.thrift.TBaseProcessor")
public abstract class TBaseProcessor_instrumentation<I> {

	
	@Trace(dispatcher = true)
	public boolean process(TProtocol in, TProtocol out) {
		return Weaver.callOriginal();
	}
}
