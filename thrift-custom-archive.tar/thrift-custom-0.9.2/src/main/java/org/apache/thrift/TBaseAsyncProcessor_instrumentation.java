package org.apache.thrift;

import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.server.AbstractNonblockingServer.AsyncFrameBuffer;

import com.newrelic.api.agent.Trace;
import com.newrelic.api.agent.weaver.MatchType;
import com.newrelic.api.agent.weaver.Weave;
import com.newrelic.api.agent.weaver.Weaver;

@Weave(type=MatchType.Interface, originalName = "org.apache.thrift.TBaseAsyncProcessor")
public abstract class TBaseAsyncProcessor_instrumentation<I> {

	@Trace(dispatcher = true)
	public boolean process(TProtocol in, TProtocol out) {
		return Weaver.callOriginal();
	}
	
	@Trace(dispatcher = true)
	public boolean process(final AsyncFrameBuffer fb)  {
		return Weaver.callOriginal();
	}
}
