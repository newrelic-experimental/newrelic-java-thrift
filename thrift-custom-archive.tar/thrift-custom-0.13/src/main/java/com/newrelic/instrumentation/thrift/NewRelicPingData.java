package com.newrelic.instrumentation.thrift;

public class NewRelicPingData {

	
	private Boolean result;
	
	public NewRelicPingData() {
		
	}

	public Boolean getResult() {
		return result;
	}

	public void setResult(Boolean result) {
		this.result = result;
	}
	
}
