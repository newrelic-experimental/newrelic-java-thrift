package com.newrelic.instrumentation.thrift;

import java.util.Map;
import java.util.logging.Level;

import org.apache.thrift.TBase;
import org.apache.thrift.TException;
import org.apache.thrift.TSerializable;
import org.apache.thrift.protocol.TMessage;
import org.apache.thrift.protocol.TMessageType;
import org.apache.thrift.protocol.TProtocol;
import org.apache.thrift.transport.TTransportException;

import com.newrelic.agent.deps.org.apache.logging.log4j.core.pattern.EqualsBaseReplacementConverter;
import com.newrelic.api.agent.NewRelic;
import com.newrelic.instrumentation.thrift.NewRelicHeaders.newrelicHeaders_args;
import com.newrelic.instrumentation.thrift.NewRelicHeaders.pingNewRelic_args;

public class NRThriftUtils {

	public static final String NEWRELIC_PING = "newrelicPing";
	public static final String NEWRELIC_HEADERS = "newrelicHeaders";

	public static ThreadLocal<NRThriftHeaders> currentHeaders = new ThreadLocal<>();
	public static ThreadLocal<Boolean> inPing = new ThreadLocal<Boolean>() {
		
		@Override
		protected Boolean initialValue() {
			return false;
		}
	};
	public static ThreadLocal<TProtocol> currentIn = new ThreadLocal<>();
	public static ThreadLocal<TProtocol> currentOut = new ThreadLocal<>();


	public static <I> void handlePing(TProtocol inProtocol, TProtocol outProtocol, int seqId) {
		NewRelic.getAgent().getLogger().log(Level.FINE, "Call to handlePing({0},{1},{3}", inProtocol,outProtocol,seqId);
		inPing.set(true);
		NewRelicPingProccesFunction<I> f = new NewRelicPingProccesFunction<>();
		pingNewRelic_args args = f.getEmptyArgsInstance();
		try {
			args.read(inProtocol);
			inProtocol.readMessageEnd();

			TSerializable result = null;
			byte msgType = TMessageType.REPLY;

			result = f.getResult(null, args);

			outProtocol.writeMessageBegin(new TMessage(NEWRELIC_PING,msgType,seqId));
			result.write(outProtocol);
			outProtocol.writeMessageEnd();
			outProtocol.getTransport().flush();
		} catch (TTransportException e) {
			NewRelic.getAgent().getLogger().log(Level.FINER, e, "Exception handling New Relic ping");
		} catch (TException e) {
			NewRelic.getAgent().getLogger().log(Level.FINER, e, "Exception handling New Relic ping");
		}
	}

	public static <I> void getHeaders(TProtocol inProtocol, TProtocol outProtocol, int seqId) {
		NewRelicHeadersProccesFunction<I> f = new NewRelicHeadersProccesFunction<>();
		newrelicHeaders_args args = f.getEmptyArgsInstance();
		try {
			inProtocol.readMessageEnd();

			if(args != null) {
				TBase result = f.getResult(null, args);
			}
		} catch (TException e) {
			NewRelic.getAgent().getLogger().log(Level.FINER, e, "Exception handling New Relic headers");
		}
	}

}
