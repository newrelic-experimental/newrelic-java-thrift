package com.newrelic.instrumentation.thrift;

import org.apache.thrift.ProcessFunction_instrumentation;
import org.apache.thrift.TBase;
import org.apache.thrift.TException;

import com.newrelic.instrumentation.thrift.NewRelicHeaders.pingNewRelic_args;
import com.newrelic.instrumentation.thrift.NewRelicHeaders.pingNewRelic_result;

public class NewRelicPingProccesFunction<I> /*extends ProcessFunction<I, NewRelicHeaders.pingNewRelic_args> */{
	
	public NewRelicPingProccesFunction() {
//		super(NRThriftUtils.NEWRELIC_PING);
	}

	protected boolean isOneway() {
		return false;
	}

	public TBase getResult(I iface, pingNewRelic_args args) throws TException {
		pingNewRelic_result result = new pingNewRelic_result();
		result.success = true;
		result.setSuccess(true);
		return result;
	}

	public pingNewRelic_args getEmptyArgsInstance() {
		return new pingNewRelic_args();
	}

	public String getMethodName() {
		return NRThriftUtils.NEWRELIC_PING;
	}


}
