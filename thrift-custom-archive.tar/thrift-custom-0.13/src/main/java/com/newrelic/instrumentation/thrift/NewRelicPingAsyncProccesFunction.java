package com.newrelic.instrumentation.thrift;

import java.util.logging.Level;

import org.apache.thrift.AsyncProcessFunction;
import org.apache.thrift.TException;
import org.apache.thrift.async.AsyncMethodCallback;
import org.apache.thrift.server.AbstractNonblockingServer.AsyncFrameBuffer;

import com.newrelic.api.agent.NewRelic;
import com.newrelic.instrumentation.thrift.NewRelicHeaders.AsyncIface;
import com.newrelic.instrumentation.thrift.NewRelicHeaders.pingNewRelic_args;
import com.newrelic.instrumentation.thrift.NewRelicHeaders.pingNewRelic_result;

public class NewRelicPingAsyncProccesFunction<I> extends AsyncProcessFunction<I, NewRelicHeaders.pingNewRelic_args, Boolean> {
	
	NewRelicAsyncIFaceImpl impl = new NewRelicAsyncIFaceImpl();
	
	public NewRelicPingAsyncProccesFunction() {
		super(NRThriftUtils.NEWRELIC_PING);
		
	}

	@Override
	protected boolean isOneway() {
		return false;
	}
 	
	@Override
	public AsyncMethodCallback<Boolean> getResultHandler(final AsyncFrameBuffer fb, final int seqid) {
        final org.apache.thrift.AsyncProcessFunction<I, NewRelicHeaders.pingNewRelic_args, Boolean>  fcall = this;
        return new AsyncMethodCallback<Boolean>() { 
          public void onComplete(Boolean o) {
            pingNewRelic_result result = new pingNewRelic_result();
            result.success = o;
            result.setSuccessIsSet(true);
            try {
              fcall.sendResponse(fb,result, org.apache.thrift.protocol.TMessageType.REPLY,seqid);
              return;
            } catch (Exception e) {
            	NewRelic.getAgent().getLogger().log(Level.FINEST, e, "Exception writing to internal frame buffer");
            }
            fb.close();
          }
          public void onError(Exception e) {
            byte msgType = org.apache.thrift.protocol.TMessageType.REPLY;
            org.apache.thrift.TBase msg;
            pingNewRelic_result result = new pingNewRelic_result();
            {
              msgType = org.apache.thrift.protocol.TMessageType.EXCEPTION;
              msg = (org.apache.thrift.TBase)new org.apache.thrift.TApplicationException(org.apache.thrift.TApplicationException.INTERNAL_ERROR, e.getMessage());
            }
            try {
              fcall.sendResponse(fb,msg,msgType,seqid);
              return;
            } catch (Exception ex) {
            	NewRelic.getAgent().getLogger().log(Level.FINEST, e, "Exception writing to internal frame buffer");
            }
            fb.close();
          }
        };
	}
	
	@Override
	public pingNewRelic_args getEmptyArgsInstance() {
		return new pingNewRelic_args();
	}

	@Override
	public void start(I iface, pingNewRelic_args args, AsyncMethodCallback<Boolean> resultHandler) throws TException {
		NewRelic.getAgent().getTransaction().ignore();
    	
		impl.pingNewRelic(resultHandler);
	}


}
