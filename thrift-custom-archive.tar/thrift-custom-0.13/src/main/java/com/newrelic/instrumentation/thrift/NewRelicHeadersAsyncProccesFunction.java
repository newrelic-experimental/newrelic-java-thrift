package com.newrelic.instrumentation.thrift;

import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

import org.apache.thrift.TException;
import org.apache.thrift.async.AsyncMethodCallback;
import org.apache.thrift.server.AbstractNonblockingServer.AsyncFrameBuffer;

import com.newrelic.api.agent.NewRelic;
import com.newrelic.instrumentation.thrift.NewRelicHeaders.newrelicHeaders_args;

public class NewRelicHeadersAsyncProccesFunction<I> extends org.apache.thrift.AsyncProcessFunction<I, newrelicHeaders_args, Void>{
	

	public NewRelicHeadersAsyncProccesFunction() {
		super(NRThriftUtils.NEWRELIC_HEADERS);
	}

	@Override
	protected boolean isOneway() {
		return true;
	}

    public void start(I iface, newrelicHeaders_args args, org.apache.thrift.async.AsyncMethodCallback<Void> resultHandler) throws TException {
    	long startTime = System.nanoTime();
    	NewRelic.getAgent().getTransaction().ignore();
		Map<String, String> headers = args.headers;
		NRThriftHeaders nrHeaders = new NRThriftHeaders();
		nrHeaders.putAll(headers);
		
		NRThriftUtils.currentHeaders.set(nrHeaders);
		long endTime = System.nanoTime();
		NewRelic.recordMetric("Custom/Newrelic/Header/Processing", TimeUnit.MILLISECONDS.convert(endTime-startTime, TimeUnit.NANOSECONDS));
      }

    public newrelicHeaders_args getEmptyArgsInstance() {
        return new newrelicHeaders_args();
      }

    public AsyncMethodCallback<Void> getResultHandler(final AsyncFrameBuffer fb, final int seqid) {
        final org.apache.thrift.AsyncProcessFunction fcall = this;
        return new AsyncMethodCallback<Void>() { 
          public void onComplete(Void o) {
          }
          public void onError(Exception e) {
          }
        };
      }

}
