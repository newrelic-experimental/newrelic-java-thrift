package com.newrelic.instrumentation.thrift;

import java.util.Map;

import org.apache.thrift.ProcessFunction_instrumentation;
import org.apache.thrift.TBase;
import org.apache.thrift.TException;

import com.newrelic.instrumentation.thrift.NewRelicHeaders.newrelicHeaders_args;

public class NewRelicHeadersProccesFunction<I> /* extends ProcessFunction<I, NewRelicHeaders.newrelicHeaders_args> */ {


	public NewRelicHeadersProccesFunction() {
		//super(NRThriftUtils.NEWRELIC_HEADERS);
	}
	
	

//	@Override
	protected boolean isOneway() {
		return true;
	}

	@SuppressWarnings("rawtypes")
//	@Override
	public TBase getResult(I iface, newrelicHeaders_args args) throws TException {
		Map<String, String> headers = args.headers;
		if(headers != null && !headers.isEmpty()) {
			NRThriftHeaders thriftHeaders = new NRThriftHeaders();
			thriftHeaders.putAll(headers);
			NRThriftUtils.currentHeaders.set(thriftHeaders);
		}
		return null;
	}

//	@Override
	public newrelicHeaders_args getEmptyArgsInstance() {
		return new newrelicHeaders_args();
	}



//	@Override
	public String getMethodName() {
		return NRThriftUtils.NEWRELIC_HEADERS;
	}


}
