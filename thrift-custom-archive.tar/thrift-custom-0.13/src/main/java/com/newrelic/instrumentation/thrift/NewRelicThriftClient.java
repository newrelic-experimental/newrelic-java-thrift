package com.newrelic.instrumentation.thrift;

import org.apache.thrift.TApplicationException;
import org.apache.thrift.TException;
import org.apache.thrift.TServiceClient;
import org.apache.thrift.protocol.TProtocol;

import com.newrelic.instrumentation.thrift.NewRelicHeaders.pingNewRelic_result;

public class NewRelicThriftClient extends TServiceClient {

	public NewRelicThriftClient(TProtocol prot) {
		super(prot);
	}
	
	public NewRelicThriftClient(TProtocol iprot, TProtocol oprot) {
	      super(iprot, oprot);
	}

	public boolean recv_ping() throws TException {
		pingNewRelic_result result = new pingNewRelic_result();
		this.receiveBase(result, NRThriftUtils.NEWRELIC_PING);
		if(result.isSetSuccess()) {
			return result.success;
		}
		throw new TApplicationException(TApplicationException.MISSING_RESULT,"newrelicPing failed");
	}
}
