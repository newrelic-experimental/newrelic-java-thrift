package org.apache.thrift;

import org.apache.thrift.protocol.TProtocol_instrumentation;

import com.newrelic.api.agent.NewRelic;
import com.newrelic.api.agent.Trace;
import com.newrelic.api.agent.TransportType;
import com.newrelic.api.agent.weaver.MatchType;
import com.newrelic.api.agent.weaver.Weave;
import com.newrelic.api.agent.weaver.Weaver;
import com.newrelic.instrumentation.thrift.NRThriftHeaders;
import com.newrelic.instrumentation.thrift.NRThriftUtils;

@Weave(type = MatchType.Interface)
public abstract class TProcessor {

//	@Trace(dispatcher = true)
//	public void process(TProtocol in, TProtocol out) {
//		NRThriftHeaders nrHeaders = NRThriftUtils.currentHeaders.get();
//		if(nrHeaders != null) {
//			NewRelic.getAgent().getTransaction().acceptDistributedTraceHeaders(TransportType.Other, nrHeaders);
//			NRThriftUtils.currentHeaders.remove();
//		}
//		Weaver.callOriginal();
//	}

}
