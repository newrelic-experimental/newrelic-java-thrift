package org.apache.thrift.async;

import java.util.logging.Level;

import com.newrelic.api.agent.NewRelic;
import com.newrelic.api.agent.Trace;
import com.newrelic.api.agent.weaver.Weave;
import com.newrelic.api.agent.weaver.Weaver;

@Weave(originalName = "org.apache.thrift.async.TAsyncClientManager")
public abstract class TAsyncClientManager_instrumentation {
	
	@Trace
	public void call(TAsyncMethodCall<?> method) {
		if(AsyncHeaderSender.isNREnabled(method)) {
			NewRelic.getAgent().getLogger().log(Level.FINE, "Can send headers for method: {0}", method);
			AsyncHeaderSender.sendHeaders(method);
		}
		Weaver.callOriginal();
	}
	
}
