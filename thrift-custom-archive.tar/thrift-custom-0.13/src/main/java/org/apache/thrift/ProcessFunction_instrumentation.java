package org.apache.thrift;

import org.apache.thrift.protocol.TProtocol_instrumentation;

import com.newrelic.api.agent.NewRelic;
import com.newrelic.api.agent.Trace;
import com.newrelic.api.agent.TransactionNamePriority;
import com.newrelic.api.agent.weaver.Weave;
import com.newrelic.api.agent.weaver.Weaver;

@Weave(originalName = "org.apache.thrift.ProcessFunction")
public abstract class ProcessFunction_instrumentation<I, T extends TBase> {
	
	 private final String methodName = Weaver.callOriginal();

	@Trace(dispatcher = true)
	public final void process(int seqid, TProtocol_instrumentation iprot, TProtocol_instrumentation oprot, I iface) throws TException {
		NewRelic.getAgent().getTracedMethod().setMetricName("Custom","Thrift","Process",methodName);
		NewRelic.getAgent().getTransaction().setTransactionName(TransactionNamePriority.FRAMEWORK_HIGH, false, "ThriftProcess", "Thrift","Process",methodName);
		Weaver.callOriginal();
	}
}
