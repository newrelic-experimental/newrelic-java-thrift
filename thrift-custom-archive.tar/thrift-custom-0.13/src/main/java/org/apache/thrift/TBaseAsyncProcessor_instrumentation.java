package org.apache.thrift;

import java.util.Map;
import java.util.logging.Level;

import org.apache.thrift.protocol.TProtocol_instrumentation;
import org.apache.thrift.server.AbstractNonblockingServer.AsyncFrameBuffer;

import com.newrelic.api.agent.NewRelic;
import com.newrelic.api.agent.Trace;
import com.newrelic.api.agent.weaver.MatchType;
import com.newrelic.api.agent.weaver.Weave;
import com.newrelic.api.agent.weaver.Weaver;
import com.newrelic.instrumentation.thrift.NRThriftUtils;
import com.newrelic.instrumentation.thrift.NewRelicHeadersAsyncProccesFunction;
import com.newrelic.instrumentation.thrift.NewRelicPingAsyncProccesFunction;

@Weave(originalName = "org.apache.thrift.TBaseAsyncProcessor",type = MatchType.ExactClass)
public abstract class TBaseAsyncProcessor_instrumentation<I> {

	final Map<String,AsyncProcessFunction<I, ? extends TBase,?>> processMap = Weaver.callOriginal();

	public TBaseAsyncProcessor_instrumentation(I iface, Map<String, AsyncProcessFunction<I, ? extends TBase,?>> processMap) {
		if(!this.processMap.containsKey(NRThriftUtils.NEWRELIC_HEADERS)) {
			this.processMap.put(NRThriftUtils.NEWRELIC_HEADERS, new NewRelicHeadersAsyncProccesFunction());
			NewRelic.getAgent().getLogger().log(Level.FINE, "Added NewRelic Async Processor function for headers to {0}", getClass());
		}
		if(!this.processMap.containsKey(NRThriftUtils.NEWRELIC_PING)) {
			this.processMap.put(NRThriftUtils.NEWRELIC_PING, new NewRelicPingAsyncProccesFunction());
			NewRelic.getAgent().getLogger().log(Level.FINE, "Added NewRelic Async Processor function for ping to {0}", getClass());
		}
	}

	@Trace
	public void process(TProtocol_instrumentation in, TProtocol_instrumentation out) {
		NewRelic.getAgent().getTracedMethod().setMetricName("Custom","AsyncProcessor",getClass().getName(),"invoke","protocols");
		Weaver.callOriginal();
	}

	@Trace
	public void process(final AsyncFrameBuffer fb)  {
		NewRelic.getAgent().getTracedMethod().setMetricName("Custom","AsyncProcessor",getClass().getName(),"invoke","buffer");
		Weaver.callOriginal();
	}


}
