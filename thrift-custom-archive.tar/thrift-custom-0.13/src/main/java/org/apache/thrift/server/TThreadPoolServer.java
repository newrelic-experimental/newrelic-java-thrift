package org.apache.thrift.server;

import org.apache.thrift.transport.TTransport;

import com.newrelic.api.agent.NewRelic;
import com.newrelic.api.agent.Token;
import com.newrelic.api.agent.Trace;
import com.newrelic.api.agent.weaver.NewField;
import com.newrelic.api.agent.weaver.Weave;
import com.newrelic.api.agent.weaver.Weaver;

@Weave
public abstract class TThreadPoolServer {

	@Weave
	private static class WorkerProcess {
		
		@NewField
		Token token = null;
		
		private WorkerProcess(TTransport client) {
			token = NewRelic.getAgent().getTransaction().getToken();
		}
		
		@Trace(async=true)
		public void run() {
			if(token != null) {
				token.linkAndExpire();
				token = null;
			}
			Weaver.callOriginal();
		}
	}
}
