package org.apache.thrift.server;

import com.newrelic.api.agent.NewRelic;
import com.newrelic.api.agent.Trace;
import com.newrelic.api.agent.TransportType;
import com.newrelic.api.agent.weaver.Weave;
import com.newrelic.api.agent.weaver.Weaver;
import com.newrelic.instrumentation.thrift.NRThriftHeaders;
import com.newrelic.instrumentation.thrift.NRThriftUtils;

@Weave
public abstract class TNonblockingServer extends AbstractNonblockingServer {

	
	@SuppressWarnings("rawtypes")
	public TNonblockingServer(AbstractNonblockingServerArgs args) {
		super(args);
	}

	@Trace(dispatcher = true)
	protected boolean requestInvoke(FrameBuffer frameBuffer) {
		NRThriftHeaders headers = NRThriftUtils.currentHeaders.get();
		if(headers != null) {
			NewRelic.getAgent().getTransaction().acceptDistributedTraceHeaders(TransportType.Other, headers);
			NRThriftUtils.currentHeaders.remove();
		}
		return Weaver.callOriginal();
	}

}
