package org.apache.thrift;

import org.apache.thrift.async.AsyncMethodCallback;

import com.newrelic.api.agent.NewRelic;
import com.newrelic.api.agent.TransactionNamePriority;
import com.newrelic.api.agent.weaver.MatchType;
import com.newrelic.api.agent.weaver.Weave;
import com.newrelic.api.agent.weaver.Weaver;

@SuppressWarnings("rawtypes")
@Weave(type =MatchType.BaseClass, originalName = "org.apache.thrift.AsyncProcessFunction")
public abstract class AsyncProcessFunction_instrumentation<I, T extends TBase, R> {
	
	public abstract String getMethodName();

	public void start(I iface, T args, AsyncMethodCallback<R> resultHandler) {
		String mName = getMethodName();
		
		NewRelic.getAgent().getTransaction().setTransactionName(TransactionNamePriority.FRAMEWORK_HIGH, false, "Thrift-Async", "Thrift","Async",getMethodName());
		Weaver.callOriginal();
	}
	
}
