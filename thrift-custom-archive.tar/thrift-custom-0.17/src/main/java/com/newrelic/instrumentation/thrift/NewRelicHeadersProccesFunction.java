package com.newrelic.instrumentation.thrift;

import java.util.Map;
import java.util.logging.Level;

import org.apache.thrift.ProcessFunction;
import org.apache.thrift.TBase;
import org.apache.thrift.TException;

import com.newrelic.instrumentation.thrift.NewRelicHeaders.Processor.newrelicHeaders;
import com.newrelic.instrumentation.thrift.NewRelicHeaders.newrelicHeaders_args;

public class NewRelicHeadersProccesFunction<I> extends ProcessFunction<I, NewRelicHeaders.newrelicHeaders_args> {
	
	private NewRelicHeaders.Processor.newrelicHeaders nrHeaders;

	public NewRelicHeadersProccesFunction() {
		super("newrelicHeaders");
		nrHeaders = new newrelicHeaders<>();
	}

	@Override
	protected boolean isOneway() {
		return nrHeaders.isOneway();
	}

	@Override
	public TBase getResult(I iface, newrelicHeaders_args args) throws TException {
		Map<String, String> headers = args.headers;
		com.newrelic.api.agent.NewRelic.getAgent().getLogger().log(Level.FINE, "Received headers: {0}",headers);
		NRThriftHeaders nrHeaders = new NRThriftHeaders();
		nrHeaders.putAll(headers);
		
		NRThriftUtils.currentHeaders.set(nrHeaders);
		return null;
	}

	@Override
	public newrelicHeaders_args getEmptyArgsInstance() {
		return nrHeaders.getEmptyArgsInstance();
	}


}
