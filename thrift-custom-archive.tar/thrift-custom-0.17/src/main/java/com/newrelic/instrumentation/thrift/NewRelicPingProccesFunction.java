package com.newrelic.instrumentation.thrift;

import org.apache.thrift.ProcessFunction;
import org.apache.thrift.TBase;
import org.apache.thrift.TException;

import com.newrelic.instrumentation.thrift.NewRelicHeaders.Processor.pingNewRelic;
import com.newrelic.instrumentation.thrift.NewRelicHeaders.pingNewRelic_args;
import com.newrelic.instrumentation.thrift.NewRelicHeaders.pingNewRelic_result;

public class NewRelicPingProccesFunction<I> extends ProcessFunction<I, NewRelicHeaders.pingNewRelic_args> {
	
	private pingNewRelic<?> ping;

	public NewRelicPingProccesFunction() {
		super("pingNewRelic");
		ping = new pingNewRelic<>();
	}

	@Override
	protected boolean isOneway() {
		return ping.isOneway();
	}

	@Override
	public TBase getResult(I iface, pingNewRelic_args args) throws TException {
		pingNewRelic_result result = new pingNewRelic_result();
		result.success = true;
		result.setSuccess(true);
		return result;
	}

	@Override
	public pingNewRelic_args getEmptyArgsInstance() {
		return ping.getEmptyArgsInstance();
	}


}
