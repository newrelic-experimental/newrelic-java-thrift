package com.newrelic.instrumentation.thrift;

public class NRThriftUtils {

	public static final String NEWRELIC_PING = "newrelicPing";
	public static final String NEWRELIC_HEADERS = "newrelicHeaders";
	
	public static ThreadLocal<NRThriftHeaders> currentHeaders = new ThreadLocal<>();
	
	
}
