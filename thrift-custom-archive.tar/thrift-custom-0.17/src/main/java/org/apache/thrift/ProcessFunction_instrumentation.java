package org.apache.thrift;

import org.apache.thrift.protocol.TProtocol;

import com.newrelic.api.agent.NewRelic;
import com.newrelic.api.agent.weaver.Weave;
import com.newrelic.api.agent.weaver.Weaver;
import com.newrelic.instrumentation.thrift.NRThriftUtils;

@Weave(originalName = "org.apache.thrift.ProcessFunction")
public abstract class ProcessFunction_instrumentation<I, T extends TBase> {

	public abstract String getMethodName();
	
	public void process(int seqid, TProtocol iprot, TProtocol oprot, I iface) {
		String mName = getMethodName();
		if(mName.equals(NRThriftUtils.NEWRELIC_PING) || mName.equals(NRThriftUtils.NEWRELIC_HEADERS)) {
			NewRelic.getAgent().getTransaction().ignore();
		}
		Weaver.callOriginal();
	}

}



