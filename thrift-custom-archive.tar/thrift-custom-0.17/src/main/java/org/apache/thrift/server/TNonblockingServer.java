package org.apache.thrift.server;

import com.newrelic.api.agent.Trace;
import com.newrelic.api.agent.weaver.Weave;
import com.newrelic.api.agent.weaver.Weaver;

@Weave
public abstract class TNonblockingServer extends AbstractNonblockingServer {

	
	@SuppressWarnings("rawtypes")
	public TNonblockingServer(AbstractNonblockingServerArgs args) {
		super(args);
	}

	@Trace
	protected boolean requestInvoke(FrameBuffer frameBuffer) {
		return Weaver.callOriginal();
	}

}
