package org.apache.thrift.async;

import java.nio.channels.Selector;

import com.newrelic.api.agent.NewRelic;
import com.newrelic.api.agent.Token;
import com.newrelic.api.agent.weaver.Weave;
import com.newrelic.api.agent.weaver.Weaver;

@Weave(originalName = "org.apache.thrift.async.TAsyncMethodCall")
public abstract class TAsyncMethodCall_instrumentation<T> {

	
	private final AsyncMethodCallback_instrumentation<T> callback = Weaver.callOriginal();
	
	
	void start(Selector sel) {
		if(callback.token == null) {
			Token t = NewRelic.getAgent().getTransaction().getToken();
			if(t != null && t.isActive()) {
				callback.token = t;
			} else if(t != null) {
				t.expire();
				t = null;
			}
		}
		if(callback.method == null) {
			callback.method = this;
		}
		Weaver.callOriginal();
	}
}
