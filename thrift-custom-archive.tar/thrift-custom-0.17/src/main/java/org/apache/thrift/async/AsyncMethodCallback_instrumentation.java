package org.apache.thrift.async;

import com.newrelic.api.agent.NewRelic;
import com.newrelic.api.agent.Token;
import com.newrelic.api.agent.Trace;
import com.newrelic.api.agent.weaver.MatchType;
import com.newrelic.api.agent.weaver.NewField;
import com.newrelic.api.agent.weaver.Weave;
import com.newrelic.api.agent.weaver.Weaver;

@Weave(type=MatchType.Interface, originalName = "org.apache.thrift.async.AsyncMethodCallback")
public abstract class AsyncMethodCallback_instrumentation<T> {

	@NewField
	public Token token = null;
	
	@NewField
	public TAsyncMethodCall_instrumentation<T> method = null;

	@Trace(async=true)
	public void onComplete(T response) {
		if(method != null) {
			NewRelic.getAgent().getTracedMethod().setMetricName("Custom","Thrift","TAsyncMethodCall","Completed",method.getClass().getSimpleName());
		}
		if(token != null) {
			token.linkAndExpire();
			token = null;
		}
		Weaver.callOriginal();
	}

	@Trace(async=true)
	public void onError(Exception exception) {
		if(method != null) {
			NewRelic.getAgent().getTracedMethod().setMetricName("Custom","Thrift","TAsyncMethodCall","Error",method.getClass().getSimpleName());
		}
		//NewRelic.noticeError(exception);
		if(token != null) {
			token.linkAndExpire();
			token = null;
		}
		Weaver.callOriginal();
	}

}
