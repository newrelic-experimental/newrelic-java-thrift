package org.apache.thrift;

import java.util.Map;

import org.apache.thrift.protocol.TProtocol;

import com.newrelic.api.agent.NewRelic;
import com.newrelic.api.agent.Trace;
import com.newrelic.api.agent.TransportType;
import com.newrelic.api.agent.weaver.MatchType;
import com.newrelic.api.agent.weaver.Weave;
import com.newrelic.api.agent.weaver.Weaver;
import com.newrelic.instrumentation.thrift.NRThriftHeaders;
import com.newrelic.instrumentation.thrift.NRThriftUtils;
import com.newrelic.instrumentation.thrift.NewRelicHeadersProccesFunction;
import com.newrelic.instrumentation.thrift.NewRelicPingProccesFunction;

@Weave(type = MatchType.BaseClass, originalName = "org.apache.thrift.TBaseProcessor")
public abstract class TBaseProcessor_instrumentation<I> {

	protected TBaseProcessor_instrumentation(I iface, Map<String, ProcessFunction<I, ? extends TBase>> processFunctionMap) {
		processFunctionMap.put(NRThriftUtils.NEWRELIC_PING, new NewRelicPingProccesFunction<I>());
		processFunctionMap.put(NRThriftUtils.NEWRELIC_HEADERS, new NewRelicHeadersProccesFunction<I>());
	}
	
	@Trace(dispatcher = true)
	public void process(TProtocol in, TProtocol out) {
		NRThriftHeaders nrHeaders = NRThriftUtils.currentHeaders.get();
		if(nrHeaders != null) {
			NewRelic.getAgent().getTransaction().acceptDistributedTraceHeaders(TransportType.Other, nrHeaders);
		}
		Weaver.callOriginal();
	}
}
